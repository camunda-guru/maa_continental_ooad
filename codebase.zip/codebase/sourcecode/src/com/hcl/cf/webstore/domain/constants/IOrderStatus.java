package com.hcl.cf.webstore.domain.constants;

public interface IOrderStatus {

	static String PENDING = "PENDING";

	static String DISPATCHED = "DISPATCHED";
}