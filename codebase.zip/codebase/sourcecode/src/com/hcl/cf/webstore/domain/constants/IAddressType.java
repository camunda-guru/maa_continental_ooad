package com.hcl.cf.webstore.domain.constants;

public interface IAddressType {

	static String SHIPPING = "SHIPPING";

	static String BILLING = "BILLING";
}