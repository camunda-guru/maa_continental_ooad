package com.hcl.cf.webstore.test.junit;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.hcl.cf.webstore.domain.entities.Cart;
import com.hcl.cf.webstore.domain.entities.CreditCard;
import com.hcl.cf.webstore.domain.interfaces.IAddress;
import com.hcl.cf.webstore.domain.interfaces.ICart;
import com.hcl.cf.webstore.domain.interfaces.ICatalog;
import com.hcl.cf.webstore.domain.interfaces.ICategory;
import com.hcl.cf.webstore.domain.interfaces.ICreditCard;
import com.hcl.cf.webstore.domain.interfaces.IItem;
import com.hcl.cf.webstore.domain.interfaces.IOrder;
import com.hcl.cf.webstore.domain.interfaces.IProduct;
import com.hcl.cf.webstore.domain.interfaces.IUserAccount;
import com.hcl.cf.webstore.domain.interfaces.IWebStoreFacade;
import com.hcl.cf.webstore.facade.WebStorePOJO;

import junit.framework.TestCase;


public class TestWebStorePOJO_Add extends TestCase {

	private IWebStoreFacade store;

	private ICart cart;

	public TestWebStorePOJO_Add(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		store = new WebStorePOJO();
		cart = new Cart();
	}

	protected void tearDown() throws Exception {
		store = null;
		cart = null;
	}

	public final void testWebStorePOJO() {
		IWebStoreFacade store1 = new WebStorePOJO();
		assertNotNull("could not create WebStorePOJO", store1);
	}

	public final void testAddCatalog() {

		ICatalog ctlg1 = store.createCatalog();
		ctlg1.setName("name1");
		ctlg1.setDescription("description1");
		assertTrue(store.addCatalog(ctlg1));

		ICatalog ctlg2 = store.createCatalog();
		ctlg2.setName("name2");
		ctlg2.setDescription("description2");
		assertTrue(store.addCatalog(ctlg2));
	}

	public final void testAddCategory() {

		List<ICatalog> list = store.getCatalogs();
		assertNotNull(list);

		ICategory ctgry1 = store.createCategory();
		ctgry1.setName("name1");
		ctgry1.setDescription("description1");

		ICategory ctgry2 = store.createCategory();
		ctgry2.setName("name2");
		ctgry2.setDescription("description2");

		ICategory ctgry3 = store.createCategory();
		ctgry3.setName("name3");
		ctgry3.setDescription("description3");

		ICategory ctgry4 = store.createCategory();
		ctgry4.setName("name4");
		ctgry4.setDescription("description4");

		ICategory ctgry5 = store.createCategory();
		ctgry5.setName("name5");
		ctgry5.setDescription("description5");

		Iterator<ICatalog> itr = list.iterator();
		while (itr.hasNext()) {
			ICatalog ctlg = itr.next();
			assertNotNull(ctlg);

			if (ctlg.getName().equals("name1")) {
				assertTrue(store.addCategory(ctlg, ctgry1));
				assertTrue(store.addCategory(ctlg, ctgry2));
			}

			else if (ctlg.getName().equals("name2")) {
				assertTrue(store.addCategory(ctlg, ctgry3));
				assertTrue(store.addCategory(ctlg, ctgry4));
				assertTrue(store.addCategory(ctlg, ctgry5));
			}
		}
	}

	public final void testAddSubCategory() {

		List<ICatalog> list1 = store.getCatalogs();
		assertNotNull(list1);

		Iterator<ICatalog> itr1 = list1.iterator();
		assertNotNull(itr1);
		while (itr1.hasNext()) {
			ICatalog ctlg = itr1.next();
			assertNotNull(ctlg);

			Set<ICategory> set = store.getCategories(ctlg);
			assertNotNull(set);

			Iterator<ICategory> itr2 = set.iterator();
			assertNotNull(itr2);

			while (itr2.hasNext()) {

				ICategory ctgry = itr2.next();
				assertNotNull(ctgry);

				ICategory ctgry1 = store.createCategory();
				ctgry1.setName("sub_name" + ctgry.getId());
				ctgry1.setDescription("description" + ctgry.getId());

				assertTrue(store.addSubCategory(ctgry, ctgry1));
			}
		}
	}

	public final void testAddProduct() {

		List<ICatalog> list1 = store.getCatalogs();
		assertNotNull(list1);

		Iterator<ICatalog> itr1 = list1.iterator();
		assertNotNull(itr1);

		while (itr1.hasNext()) {
			ICatalog ctlg = itr1.next();
			assertNotNull(ctlg);

			Set<ICategory> set = store.getCategories(ctlg);
			assertNotNull(set);

			Iterator<ICategory> itr2 = set.iterator();
			assertNotNull(itr2);

			while (itr2.hasNext()) {
				ICategory ctgry = itr2.next();
				assertNotNull(ctgry);

				Set<ICategory> set2 = store.getSubCategories(ctgry);
				assertNotNull(set2);

				Iterator<ICategory> itr3 = set2.iterator();
				assertNotNull(itr3);

				while (itr3.hasNext()) {
					ICategory sub_ctgry = itr3.next();
					assertNotNull(sub_ctgry);

					IProduct prd = store.createProduct();
					prd.setName("name" + sub_ctgry.getId());
					prd.setDescription("description" + sub_ctgry.getId());
					assertTrue(store.addProduct(sub_ctgry, prd));
				}
			}
		}
	}

	public final void testAddItem() {

		IProduct p1 = store.getProduct(1);
		assertNotNull(p1);

		IProduct p2 = store.getProduct(2);
		assertNotNull(p2);

		IProduct p3 = store.getProduct(3);
		assertNotNull(p3);

		IProduct p4 = store.getProduct(6);
		assertNotNull(p4);

		IProduct p5 = store.getProduct(5);
		assertNotNull(p5);

		IItem i1 = store.createItem();
		assertNotNull(i1);
		i1.setName("name1");
		i1.setDescription("description1");
		i1.setPrice(1d);
		//p1.setUnits(1000l);
		assertTrue(store.addItem(p1, i1));

		IItem i2 = store.createItem();
		assertNotNull(i2);
		i2.setName("name2");
		i2.setDescription("description2");
		i2.setPrice(2d);
		//p2.setUnits(2000l);
		assertTrue(store.addItem(p2, i2));

		IItem i3 = store.createItem();
		assertNotNull(i3);
		i3.setName("name3");
		i3.setDescription("description3");
		i3.setPrice(3d);
		//p3.setUnits(3000l);
		assertTrue(store.addItem(p3, i3));

		IItem i4 = store.createItem();
		assertNotNull(i4);
		i4.setName("name4");
		i4.setDescription("description4");
		i4.setPrice(4d);
		//p4.setUnits(4000l);
		assertTrue(store.addItem(p4, i4));

		IItem i5 = store.createItem();
		assertNotNull(i5);
		i5.setName("name5");
		i5.setDescription("description5");
		i5.setPrice(5d);
		//p5.setUnits(5000l);
		assertTrue(store.addItem(p5, i5));
	}

	public final void testAddUserAccount() {

		IUserAccount ua1 = store.createUserAccount();
		assertNotNull(ua1);
		ua1.setBirthDate(new Date());
		ua1.setEmailID("e1");
		ua1.setFirstName("f1");
		ua1.setLastName("l1");
		ua1.setPassword("p1");
		ua1.setUserName("u1");

		ICreditCard cc1 = store.createCreditCard();
		assertNotNull(cc1);
		cc1.setCardType("ca1");
		cc1.setCreditCardNumber(1414141);
		cc1.setExpiryDate(new Date());

		IAddress add1 = store.createAddress();
		assertNotNull(add1);
		add1.setAddress("ad1");
		add1.setCity("ci1");
		add1.setCountry("coun1");
		add1.setState("st1");
		add1.setType("ty1");
		add1.setZip(12);

		ua1.setIAddress(add1);
		assertTrue(store.addUserAccount(ua1));
	}

	public final void testAddOrder() {

		ICart cart1 = store.createCart();
		cart1.addItem(store.getItem(1));
		cart1.addItem(store.getItem(2));
		cart1.addProduct(store.getProduct(1), 1);
		cart1.addProduct(store.getProduct(2), 1);

		ICreditCard ic1 = new CreditCard();
		ic1.setCardType("VISA");
		ic1.setCreditCardNumber(121212121);
		ic1.setExpiryDate(new Date());

		IOrder order1 = store.createOrder();
		order1.setIUserAccount(store.getUserAccount(1));
		order1.setICart(cart1);
		order1.setDate(new Date());
		order1.setOrderStatus("pending");
		order1.setIShippingAddress(store.getUserAccount(1).getIAddress());
		order1.setICreditCard(ic1);
		assertEquals(true, store.addOrder(order1));
	}

	public final void testCreateCart() {

		assertNotNull("could not create Cart", store.createCart());
		//assertNotNull(store.createCart());
	}

	public final void testCreateAddress() {
		assertNotNull("could not create Cart", store.createAddress());
	}

	public final void testCreateCatalog() {
		assertNotNull("could not create Cart", store.createCatalog());
	}

	public final void testCreateCategory() {
		assertNotNull("could not create Cart", store.createCategory());
	}

	public final void testCreateCreditCard() {
		assertNotNull("could not create Cart", store.createCreditCard());
	}

	public final void testCreateImage() {
		assertNotNull("could not create Cart", store.createImage());
	}

	public final void testCreateItem() {
		assertNotNull("could not create Cart", store.createItem());
	}

	public final void testCreateOrder() {
		assertNotNull("could not create Cart", store.createOrder());
	}

	public final void testCreateProduct() {
		assertNotNull("could not create Cart", store.createProduct());
	}

	public final void testCreateUserAccount() {
		assertNotNull("could not create Cart", store.createUserAccount());
	}

	public final void testAddProductToCart()
	{
		assertEquals(true, cart.addProduct(store.createProduct(), 10));
	}

	public final void testAddItemToCart()
	{
		assertEquals(true, cart.addItem(store.createItem()));
	}
}