package com.hcl.cf.webstore.test.junit;

import com.hcl.cf.webstore.domain.interfaces.ICatalog;
import com.hcl.cf.webstore.domain.interfaces.ICategory;
import com.hcl.cf.webstore.domain.interfaces.IItem;
import com.hcl.cf.webstore.domain.interfaces.IProduct;
import com.hcl.cf.webstore.domain.interfaces.IUserAccount;
import com.hcl.cf.webstore.domain.interfaces.IWebStoreFacade;
import com.hcl.cf.webstore.facade.WebStorePOJO;

import junit.framework.TestCase;

public class TestWebStorePOJO_Update extends TestCase {

	private IWebStoreFacade store;

	public TestWebStorePOJO_Update(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		store = new WebStorePOJO();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public final void testUpdateCatalog() {

		ICatalog ct1 = store.getCatalog(1);
		ct1.setDescription("description1...updated");
		ICatalog ct2 = store.getCatalog(2);
		ct2.setDescription("description2...updated");
		store.updateCatalog(ct1);
		store.updateCatalog(ct2);

		assertTrue(store.getCatalog(1).getDescription().equals(
		"description1...updated"));
		assertTrue(store.getCatalog(2).getDescription().equals(
		"description2...updated"));
	}

	public final void testUpdateCategory() {

		ICategory ctg1 = store.getCategory(1);
		ICategory ctg9 = store.getCategory(9);

		ctg1.setDescription("description1...updated");
		ctg9.setDescription("description9...updated");

		store.updateCategory(ctg1);
		store.updateCategory(ctg9);

		assertTrue(store.getCategory(1).getDescription().equals(
		"description1...updated"));
		assertTrue(store.getCategory(9).getDescription().equals(
		"description9...updated"));
	}

	public final void testUpdateItem() {

		IItem i1 = store.getItem(1);
		i1.setDescription("description1...updated");
		IItem i2 = store.getItem(2);
		i2.setDescription("description2...updated");

		store.updateItem(i1);
		store.updateItem(i2);

		assertTrue(store.getItem(1).getDescription().equals(
		"description1...updated"));
		assertTrue(store.getItem(2).getDescription().equals(
		"description2...updated"));
	}

	public final void testUpdateProduct() {

		IProduct i1 = store.getProduct(1);
		i1.setDescription("description1...updated");
		IProduct i2 = store.getProduct(2);
		i2.setDescription("description2...updated");

		store.updateProduct(i1);
		store.updateProduct(i2);

		assertTrue(store.getProduct(1).getDescription().equals(
		"description1...updated"));
		assertTrue(store.getProduct(2).getDescription().equals(
		"description2...updated"));
	}

	public final void testUpdateUserAccount() {

		IUserAccount i1 = store.getUserAccount(1);
		i1.setFirstName("fname1...updated");

		store.updateUserAccount(i1);

		assertTrue(store.getUserAccount(1).getFirstName().equals(
		"fname1...updated"));
	}
}