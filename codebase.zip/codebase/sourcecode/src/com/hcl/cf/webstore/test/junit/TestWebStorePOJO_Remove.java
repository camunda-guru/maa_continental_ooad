package com.hcl.cf.webstore.test.junit;

import com.hcl.cf.webstore.domain.interfaces.IUserAccount;
import com.hcl.cf.webstore.domain.interfaces.IWebStoreFacade;
import com.hcl.cf.webstore.facade.WebStorePOJO;

import junit.framework.TestCase;

public class TestWebStorePOJO_Remove extends TestCase {

	private IWebStoreFacade store;
	private IUserAccount account;

	public TestWebStorePOJO_Remove(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		store = new WebStorePOJO();
	}

	protected void tearDown() throws Exception {
		store = null;
	}

	public final void testRemoveOrder() {

	}

	public final void testRemoveItem() {
		assertEquals(true, store.removeItem(store.getProduct(2), store.getItem(1)));
	}

	public final void testRemoveProduct() {
		assertEquals(true, store.removeProduct(store.getCategory(7), store.getProduct(1)));
	}	

	public final void testRemoveUserAccount() {
		account = store.getUserAccount("sushanth");
		assertNotNull(store.removeUserAccount(account));
	}

	public final void testRemoveCategory() {
		assertEquals(true, store.removeCategory(store.getCatalog(1), store.getCategory(1)));
	}

	public final void testRemoveCatalog() {
		assertEquals(true, store.removeCatalog(store.getCatalog(5)));
	}
}