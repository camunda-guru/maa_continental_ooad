package com.hcl.cf.webstore.test.junit;

import com.hcl.cf.webstore.domain.interfaces.ICatalog;
import com.hcl.cf.webstore.domain.interfaces.IWebStoreFacade;
import com.hcl.cf.webstore.facade.WebStorePOJO;

import junit.framework.TestCase;

public class TestWebStorePOJO_Select extends TestCase {

	private IWebStoreFacade store;

	public TestWebStorePOJO_Select(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		store = new WebStorePOJO();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public final void testGetCatalog() {

		ICatalog cat1 = store.getCatalog(1);
		assertNotNull(cat1);

		ICatalog cat2 = store.getCatalog(2);
		assertNotNull(cat2);
	}

	public final void testGetCatalogs() {

		assertNotNull(store.getCatalogs());
	}

	public final void testGetCategory() {

		assertNotNull(store.getCategory(1));
		assertNotNull(store.getCategory(2));
		assertNotNull(store.getCategory(3));
		assertNotNull(store.getCategory(4));
		assertNotNull(store.getCategory(5));
		assertNotNull(store.getCategory(6));
		assertNotNull(store.getCategory(7));
		assertNotNull(store.getCategory(8));
		assertNotNull(store.getCategory(9));
		assertNotNull(store.getCategory(10));
	}

	public final void testGetCategories() {

		assertNotNull(store.getCategories(store.getCatalog(1)));
		assertNotNull(store.getCategories(store.getCatalog(2)));
	}

	public final void testGetItem() {

		assertNotNull(store.getItem(1));
		assertNotNull(store.getItem(2));
	}

	public final void testGetItems() {

		assertNotNull(store.getItems(store.getProduct(2)));
	}

	public final void testGetOrder() {

		assertNotNull(store.getOrder(1));
	}

	public final void testGetOrders() {

		assertNotNull(store.getOrders("sushanth"));
	}

	public final void testGetProduct() {

		assertNotNull(store.getProduct(1));
		assertNotNull(store.getProduct(2));
		assertNotNull(store.getProduct(3));
		assertNotNull(store.getProduct(4));
		assertNotNull(store.getProduct(5));
	}

	public final void testGetProducts() {

		assertNotNull(store.getProducts(store.getCategory(7)));
	}

	public final void testGetSubCategories() {

		assertNotNull(store.getSubCategories(store.getCategory(5)));
	}

	public final void testGetUserAccountByID() {

		assertNotNull(store.getUserAccount(1));
	}

	public final void testGetUserAccountByUserName() {

		assertNotNull(store.getUserAccount("sushanth"));
	}

	public final void testGetUserAccountByUserNameAndPassword() {

		assertNotNull(store.getUserAccount("sushanth" , "sush"));
	}

	public final void testHasDisplayableItem() {

		assertTrue(store.hasDisplayableItem(store.getProduct(2)));
	}

	public final void testHasProducts() {

		assertTrue(store.hasProducts(store.getCategory(4)));
		assertTrue(store.hasProducts(store.getCategory(7)));
	}

	public final void testHasSubCategories() {

		assertTrue(store.hasSubCategories(store.getCategory(5)));
	}

	public final void testGetItemsCount(){
		assertEquals(new Integer(2), store.getItemsCount(store.getProduct(2)));
	}
}