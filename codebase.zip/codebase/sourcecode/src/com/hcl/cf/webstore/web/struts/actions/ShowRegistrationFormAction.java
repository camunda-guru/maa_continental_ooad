package com.hcl.cf.webstore.web.struts.actions;

public class ShowRegistrationFormAction {

	public String execute() {
		return "success";
	}
}