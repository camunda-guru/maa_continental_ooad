package com.hcl.cf.webstore.dao.implementation;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hcl.cf.webstore.dao.interfaces.IOrderDAO;
import com.hcl.cf.webstore.domain.entities.Order;
import com.hcl.cf.webstore.domain.interfaces.IOrder;
import com.hcl.cf.webstore.hibernate.util.HibernateUtil;

public class OrderDAO implements IOrderDAO {

	/*
	 * @param order @return
	 */
	public boolean addOrder(IOrder order) {

		if (order == null)
			return false;

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();

		try {
			session.beginTransaction();
			session.save(order);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.getTransaction().commit();
		}
		return true;
	}

	/*
	 * @param id @return
	 */
	public IOrder getOrder(long id) {

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		IOrder order = null;

		try {
			session.beginTransaction();
			order = (IOrder) session.load(Order.class, new Long(id));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.getTransaction().commit();
		}
		return order;
	}

	/*
	 * @param userName @return
	 */
	public Set<IOrder> getOrders(String userName) {

		if (userName == null || userName.isEmpty())
			return null;

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		List list = null;

		try {
			session.beginTransaction();

			Query query = session
			.createQuery("from Order order where order.userAccount.userName = ?");
			query.setString(0, userName);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.getTransaction().commit();
		}
		return new HashSet<IOrder>(list);
	}
}