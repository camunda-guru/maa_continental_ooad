package com.hcl.cf.webstore.domain.constants;

public interface ICreditCardType {

	static String VISA = "VISA";

	static String MASTER = "MASTER";
}