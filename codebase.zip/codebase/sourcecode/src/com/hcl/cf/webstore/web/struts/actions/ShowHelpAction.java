package com.hcl.cf.webstore.web.struts.actions;

public class ShowHelpAction {

	public String execute() {
		return "success";
	}
}