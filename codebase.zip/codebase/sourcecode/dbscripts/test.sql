﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `tradeproc` $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `tradeproc`()
BEGIN
select TRADE_ID,SIDE,SYMBOL,SHARES,PRICE,STATE from trade;

END $$

DELIMITER ;