public class Memento
{
public Memento(Drawing d){}
public void restore(){}
}
