//this class is just a simple collection of arrays
//of the data which has been selected
import java.util.*;
public class Data
{
  Kid[] kids;
  public Data(Kid[] kd)
  {
     kids = kd;
  }            
  public Kid[] getData()
  {
     return kids;
  }
}
