public class SwimmerNoSex extends SwimData
{
   public SwimmerNoSex()
   {
   }
   public void sortByTime()
   {
   }
}
